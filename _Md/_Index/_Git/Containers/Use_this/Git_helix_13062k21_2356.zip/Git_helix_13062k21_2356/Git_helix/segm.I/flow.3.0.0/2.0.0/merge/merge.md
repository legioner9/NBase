```


[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.7/v1)
[init from](create.1.0.0_to_2.0.0.md)

[gh brn]
    <>Switched to branch 'brn'
[echo cnt_6 > v1]
[gc v1 -m v1=cnt_6]
    <>[brn bd7b93d] v1=cnt_6
    1 file changed, 1 insertion(+), 1 deletion(-)

    ON branch brn
    $ Untracked files:{{fun}} 

    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* bd7b93d - (3 minutes ago) v1=cnt_6 - Legioner9 (HEAD -> brn)
* 6f97660 - (2 hours ago) v1=cnt_2 - Legioner9
| * 057224d - (16 minutes ago) v1=cnt_5 - Legioner9 (master)
| * 594d4a4 - (54 minutes ago) v1=cnt_4 - Legioner9
|/
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

        reflex[git diff bd7b93d 057224d]
            <>diff --git a/v1 b/v1
            index 9c91221..3b25212 100644
            --- a/v1
            +++ b/v1
            @@ -1 +1 @@
            -cnt_6
            +cnt_5

------------------------------------------------------------------------------
[go](NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\proj.2.0.0\set.2.0.0.merge\v1)

[gh master]
    <>Switched to branch 'master'
[git merge brn]
    <>Auto-merging v1
    CONFLICT (content): Merge conflict in v1
    Automatic merge failed; fix conflicts and then commit the result.
[cat v1]
    <><<<<<<< HEAD
    cnt_5
    =======
    cnt_6
    >>>>>>> brn
[echo cnt_5+6 > v1]
[ga v1]
[gs]
    <>On branch master
    All conflicts fixed but you are still merging.
    (use "git commit" to conclude merge)

    Changes to be committed:
            modified:   v1

    Untracked files:
    (use "git add <file>..." to include in what will be committed)
            fun
[gc -m merge:v1=cnt_5+6]
<>[master 377f4fa] merge:v1=cnt_5+6

    ON branch brn
    $ Untracked files:{{fun}} 

    $$ 377f4fa: master: -> merge:v1=cnt_5+6:{{v1:@@@ -1,1 -1,1 +1,1 @@@
                                                    - cnt_5
                                                    -cnt_6
                                                    ++cnt_5+6
                                                    }}

    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

    $$ hash: Branch: -> Precedes:{{file:}}

*   377f4fa - (6 minutes ago) merge:v1=cnt_5+6 - Legioner9 (HEAD -> master)
|\
| * bd7b93d - (10 hours ago) v1=cnt_6 - Legioner9 (brn)
| * 6f97660 - (12 hours ago) v1=cnt_2 - Legioner9
* | 057224d - (10 hours ago) v1=cnt_5 - Legioner9
* | 594d4a4 - (11 hours ago) v1=cnt_4 - Legioner9
|/
* 4016163 - (10 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

------------------------------------------------------------------------------

        reflex[]
        <>
        ............

```