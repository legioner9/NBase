    (*)            
    {shape_8}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }
    (*)
        {{}}
            [git stash]
                <>Saved working directory and index state WIP on master: 2fb793a empty v1
                [gs]
                    <>...
                [gw]
                    <>*prev*
                [gg]
                    <>*   34f9654 - (17 minutes ago) WIP on master: 2fb793a empty v1 - legioner9 (refs/stash)        
                    |\
                    | * a620541 - (17 minutes ago) index on master: 2fb793a empty v1 - legioner9
                    |/
                    * 2fb793a - (5 days ago) empty v1 - legioner9 (HEAD -> master, bare/master)
    (*)            
    {shape_9}={
        {st}={        
            {fs}={
                34f9654::v1:'cng_2',
            }
            {in}={
                a620541::v1:'cng_1',
            }
        }
        {fs}={
            v1:'',
        }
        {ws}={}
        {in}={}
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }
        }
    (*)
        {{}}
            [ch a620541 v1]
                <>Updated 1 path from f7b62f8
                [gs]
                    <>Changes to be committed:
                    modified:   v1(=cng_1)
                [gw]
                    <>
                [gg]
                    <>
    (*)            
    {shape_10}={
        {st}={*prev*}
        {fs}={
            v1:cng_1
        }
        {ws}={}
        {in}={
            v1:cng_1
        }
        {lr}={*prev*}
        {ur}={*prev*}
        }


-------------------------------
    (*)
        {{}}
            []
                <>
                [gs]
                    <>
                [gw]
                    <>
                [gg]
                    <>
    (*)            
    {shape_...}={
        {st}={}
        {fs}={}
        {ws}={}
        {in}={}
        {lr}={}
        {ur}={}
        }
-------------------------------