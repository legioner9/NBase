## first step

    git submodule init ../sub

    Cloning into 'F:/Node_projects/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix_04032k21_2000/Git_helix/segm.III/SubModules.v.0.1/fset.1.0.0/set.2.0.0/sub'...
    done.
    warning: LF will be replaced by CRLF in .gitmodules.
    The file will have its original line endings in your working directory
    [1]+  Done                    gitk --all

    $ cat .gitmodules
    
    [submodule "sub"]
            path = sub
            url = ../sub`