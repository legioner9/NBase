                $ Untracked files:{{fun:cnt_un}}
                $$ not checked in to index{{v1:@@ -1 +1 @@
                                                -cnt_2
                                                +cnt_3}}
                $$ in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}
                    * 4c2ab9e - (4 days ago) v1=cnt_1 - legioner9 (HEAD -> master){{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
                    * 3a462c6 - (4 days ago) v1=cnt_0 - legioner9 (bare/master){{v1:@@ -0,0 +1 @@
                        +cnt_0}}