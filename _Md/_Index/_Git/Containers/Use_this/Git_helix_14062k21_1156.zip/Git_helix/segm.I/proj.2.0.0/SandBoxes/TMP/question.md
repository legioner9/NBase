
git init
echo added_to_index > v1
git add v1
echo added_to_cach > v1
git commit v1 -m 'cach_or_index_be_commited?'
rm v1
git restore v1
cat v1


для справки : перед коммитом `git status` выдал следующее:

Changes to be committed:
  (use "git rm --cached \<file>..." to unstage)
        new file:   v1

Changes not staged for commit:
  (use "git add \<file>..." to update what will be committed)
  (use "git restore \<file>..." to discard changes in working directory)
        modified:   v1
