## first step

    git submodule init ../sub

    Cloning into 'F:/Node_projects/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix_04032k21_2000/Git_helix/segm.III/SubModules.v.0.1/fset.1.0.0/set.2.0.0/sub'...
    done.
    warning: LF will be replaced by CRLF in .gitmodules.
    The file will have its original line endings in your working directory
    [1]+  Done                    gitk --all

    $ cat .gitmodules
    
    [submodule "sub"]
            path = sub
            url = ../sub

    
    $ git submodule init
    
        Submodule 'sub' (F:/Node_projects/Node_Way/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix/segm.I.v.1.0.0/fproj.1.0.0/fset.1.0.0/sub) registered for path 'sub'

    !!! .git/config:

        [submodule "sub"]
        active = true
        url = ../sub

    $ git submodule update

        Cloning into 'F:/Node_projects/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix/segm.III/Set_from_SubModules.v.0.1/_Pull_push_for_sub/3_submodule_update/fset.1.0.0/clone/sub'...
        done.
        Submodule path 'sub': checked out '9c148f9ad0d9093481be8d2286200fa1b83cfa22'
        [1]+  Done                    gitk --all  (wd: /f/Node_projects/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix/segm.III/Set_from_SubModules.v.0.1/_Pull_push_for_sub/3_submodule_update/fset.1.0.0/clone_bare)
        (wd now: /f/Node_projects/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix/segm.III/Set_from_SubModules.v.0.1/_Pull_push_for_sub/3_submodule_update/fset.1.0.0/clone)

## united commands

    $ git clone --recurse-submodules <url_bare_main_progect>

    $ git submodule update --remote
