## Sub Module

git submodule add ../subBare bare/

.gitmodules

    [submodule "bare"]
        path = bare
        url = ../subBare

config

    [submodule "bare"]
        url = F:/Node_projects/NBase/_Md/_Index/_Git/Containers/Use_this/Git_helix_16062k21_0053/segm.III/SubModules_2/fset.1.0.0/subBare
        active = true

edit to relative path

        url = ../subBare

